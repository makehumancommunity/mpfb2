#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, bpy
from mpfb import CLASSMANAGER
from mpfb.services.logservice import LogService
from mpfb.services.sceneconfigset import SceneConfigSet
from mpfb.services.uiservice import UiService

_LOC = os.path.dirname(__file__)
MAKESKIN_PROPERTIES_DIR = os.path.join(_LOC, "properties")
MAKESKIN_PROPERTIES = SceneConfigSet.from_definitions_in_json_directory(MAKESKIN_PROPERTIES_DIR, prefix="MS_")

_LOG = LogService.get_logger("makeskin.makeskinpanel")

class MPFB_PT_MakeSkin_Panel(bpy.types.Panel):
    bl_label = "MakeSkin"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = UiService.get_value("MATERIALSCATEGORY")

    def draw(self, context):
        _LOG.enter()
        layout = self.layout
        scn = context.scene

        #MAKESKIN_PROPERTIES.draw_properties(scn, layout, ["presets_for_import", "settings_for_import"])
        layout.operator('mpfb.write_makeskin_material')
        layout.operator('mpfb.import_makeskin_material')
        layout.operator('mpfb.create_makeskin_material')


CLASSMANAGER.add_class(MPFB_PT_MakeSkin_Panel)
