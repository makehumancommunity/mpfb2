#!/usr/bin/python
# -*- coding: utf-8 -*-

from mpfb.services import LogService as _LogService
_LOG = _LogService.get_logger("makeskin.init")
_LOG.trace("initializing makeskin module")

from .makeskinpanel import MPFB_PT_MakeSkin_Panel
from .operators import *

__all__ = [
    "MPFB_PT_MakeSkin_Panel"
    ]
