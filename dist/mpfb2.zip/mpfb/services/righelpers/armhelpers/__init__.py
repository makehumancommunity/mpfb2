from mpfb.services.logservice import LogService

_LOG = LogService.get_logger("armhelpers.init")
_LOG.trace("initializing armhelpers module")
