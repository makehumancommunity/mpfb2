from mpfb.services.logservice import LogService

_LOG = LogService.get_logger("leghelpers.init")
_LOG.trace("initializing leghelpers module")
