from mpfb.services.logservice import LogService

_LOG = LogService.get_logger("fingerhelpers.init")
_LOG.trace("initializing fingerhelpers module")
