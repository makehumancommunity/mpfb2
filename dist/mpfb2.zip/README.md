# MakeHuman Plugin For Blender (MPFB)

This is the addon that can be installed in blender.

